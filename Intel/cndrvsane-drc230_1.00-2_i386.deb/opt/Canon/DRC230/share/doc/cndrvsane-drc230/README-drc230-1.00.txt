=================================================================================
Canon Electronics Scanner Driver for Linux Version 1.00

PLEASE READ THIS DOCUMENT CAREFULLY
=================================================================================

---------------------------------------------------------------------------------
Trademarks
SANE


---------------------------------------------------------------------------------


---------------------------------------------------------------------------------
CONTENTS

Before Starting
1. Introduction
2. Distribution File Structure of the Canon Electronics Scanner Driver for Linux
3. Hardware Requirements
4. Cautions, Limitations, and Restrictions
---------------------------------------------------------------------------------


1. Introduction -----------------------------------------------------------------
Thank you for using the Canon Electronics Scanner Driver for Linux. This scannner 
driver provides scanning functions for Canon Electronics scanners operating under
the SANE (Scan Access Now Easy) environment, a scanning system that operates on 
Linux operating systems.


2. Distribution File Structure of the Canon Electronics Scanner Driver for Linux -----
The Canon Electronics Scanner Driver for Linux distribution files are as follows:
Furthermore, the file name for the SANE driver common module and scanner driver
module differs depending on the version.

- README-drc230-1.00.txt (This document)
Describes supplementary information on the Canon Electronics Scanner Driver for Linux.

- LICENSE-drc230-1.00x.txt
Describes User License Agreement on the Canon Electronics Scanner Driver for Linux.

- cndrvsane-drc230-1.00-X.x86_64.rpm (for 64-bit)
- cndrvsane-drc230_1.00-X_amd64.deb (for Debian 64-bit)
Installation package for the Canon Electronics Scanner Driver for Linux.

3. Hardware Requirements --------------------------------------------------------
This Scanner driver can be used with the following hardware environment.

Hardware: Computer that is enable to operate Linux, with x86_64 compatible CPU
          (64-bit)

Suppoeted Scanner: DRC230


4. Cautions, Limitations, and Restrictions -------------------------------------
This Scanner driver is tested on the following OS environment.

- Debian GNU Linux 7.0
- Debian GNU Linux 8.0
- Debian GNU Linux 9.0
- Ubuntu 15.04 Desktop
- Ubuntu 15.10 Desktop
- Ubuntu 16.04 Desktop
- Ubuntu 16.10 Desktop
- Ubuntu 17.04 Desktop
- Fedora 22
- Fedora 23
- Fedora 24
- Fedora 25
- Fedora 26
- openSUSE Tumbleweed (Snapshot 20180319)

At scanning under [DEKSEW=checked] and [User Defined Size], the Top-Left
position of image is the Top-Left position of detected document regardless of
the setting of tl-x and tl-y;


=================================================================================
Support
=================================================================================
This Software and Related Information are independently developed by Canon and
distributed by Canon local company. Canon as manufacturer of scanners supporting
the Software and Related Information ("Canon Scanners"), and Canon local company
as selling agency of Canon Scanners, do not receive any user support call and
/or request or any requests for information about the Software and Related
Information. Any demand for information about Canon Scanners including
information about the repair and supplies for Canon Scanners should be directed
to Canon local company.
=================================================================================
                                            Copyright CANON ELECTRONICS INC. 2018
